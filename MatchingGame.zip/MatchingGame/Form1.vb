﻿Public Class Form1
    Private firstClicked As Label = Nothing
    Private secondClicked As Label = Nothing
    Private random As New Random
    Private icons =
      New List(Of String) From {"Apple", "Fruit", "Broccoli", "Vegetable", "Chicken", "Meat", "Milk", "Dairy",
                                "Bread", "Grain", "Yogurt", "Dairy", "Cookie", "Fats", "Carrot", "Vegetable"}

    Private Sub AssignIconsToSquares()
        'Method used to assign the list of strings to squares
        For Each control In TableLayoutPanel1.Controls ' All 16 labels listed on TableLayoutPanel1
            Dim iconLabel = TryCast(control, Label) 'Assigns 1 of the 16 labels to the variable iconLabel
            If iconLabel IsNot Nothing Then 'if iconLabel has a label assigned execute following code
                Dim randomNumber = random.Next(icons.Count) 'assigns a random number from the 16 list of strings
                iconLabel.Text = icons(randomNumber) 'whichever number is chosen, the text of the string will be the Label text
                iconLabel.ForeColor = iconLabel.BackColor 'sets the label to be green (invisible)
                icons.RemoveAt(randomNumber) 'removes the string from the list of strings so there are no duplicates
            End If
        Next

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AssignIconsToSquares()
    End Sub

    Private Sub label_Click(sender As Object, e As EventArgs) Handles Label9.Click, Label8.Click, Label7.Click, Label6.Click, Label5.Click, Label4.Click, Label3.Click, Label2.Click, Label16.Click, Label15.Click, Label14.Click, Label13.Click, Label12.Click, Label11.Click, Label10.Click, Label1.Click
        'Event runs when a label is clicked
        If Timer1.Enabled Then
            Exit Sub
        End If

        Dim clickedLabel = TryCast(sender, Label) 'assigns the selected label to clickedLabel

        If clickedLabel IsNot Nothing Then 'checks whether the clicked label has already been chosen
            If clickedLabel.ForeColor = Color.Black Then
                Exit Sub
            End If

            If firstClicked Is Nothing Then 'checks if firstClicked has a value stored
                firstClicked = clickedLabel 'stores label into firstClicked
                firstClicked.ForeColor = Color.Black 'makes label visible
                Exit Sub
            End If

            'ONLY executes if the firstClicked does have a label assigned
            secondClicked = clickedLabel 'stores the label that was selected secong into secondClick
            secondClicked.ForeColor = Color.Black 'makes label visible

            CheckForWinner()
            CheckPair()
        End If


    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        'Timer tick event ONLY runs if the pair of labels selcted are incorrect
        'This event stops resets the color of the two labels selcted and sets their value to Nothing
        Timer1.Stop() 'Stop timer from running to allow for future resets

        firstClicked.ForeColor = firstClicked.BackColor 'makes labels invisible
        secondClicked.ForeColor = secondClicked.BackColor

        firstClicked = Nothing 'sets label values to nothing
        secondClicked = Nothing
    End Sub
    Private Sub CheckForWinner()
        'Event runs to see if the all of the labels are visible, meaning they have been matched correctly

        For Each control In TableLayoutPanel1.Controls
            'Loop checks every label and tests the visibility of each label
            'If the forcolor of the label is the same as the backcolor 
            'then the label is invisible meaning the the player did not finish matching all pairs
            Dim iconLabel = TryCast(control, Label)
            If iconLabel IsNot Nothing AndAlso
               iconLabel.ForeColor = iconLabel.BackColor Then
                Exit Sub
            End If
        Next

        'if the player did match all pairs, then message box appears and closes program
        MessageBox.Show("You matched all the icons!", "Congratulations")
        Close()

    End Sub
    Private Sub CheckPair()
        'Method called to check if a pair is correct 
        'There are 16 if statements because there are 8 pairs, but the pairs can be selected two ways
        'Ex: firstlabel = apple and secondlabel = fruit OR firstlabel = Fruit and secondlabel = apple
        If firstClicked.Text = "Apple" And secondClicked.Text = "Fruit" Then 'if this statement is true
            firstClicked.ForeColor = Color.Black 'sets both labels to be visible
            secondClicked.ForeColor = Color.Black
            firstClicked = Nothing 'resets the value of both labels
            secondClicked = Nothing
            Exit Sub ' falls out of loop

        ElseIf firstClicked.Text = "Fruit" And secondClicked.Text = "Apple" Then
            firstClicked.ForeColor = Color.Black
            secondClicked.ForeColor = Color.Black
            firstClicked = Nothing
            secondClicked = Nothing
            Exit Sub
        ElseIf firstClicked.Text = "Broccoli" And secondClicked.Text = "Vegetable" Then
            firstClicked.ForeColor = Color.Black
            secondClicked.ForeColor = Color.Black
            firstClicked = Nothing
            secondClicked = Nothing
            Exit Sub
        ElseIf firstClicked.Text = "Chicken" And secondClicked.Text = "Meat" Then
            firstClicked.ForeColor = Color.Black
            secondClicked.ForeColor = Color.Black
            firstClicked = Nothing
            secondClicked = Nothing
            Exit Sub
        ElseIf firstClicked.Text = "Meat" And secondClicked.Text = "Chicken" Then
            firstClicked.ForeColor = Color.Black
            secondClicked.ForeColor = Color.Black
            firstClicked = Nothing
            secondClicked = Nothing
            Exit Sub
        ElseIf firstClicked.Text = "Milk" And secondClicked.Text = "Dairy" Then
            firstClicked.ForeColor = Color.Black
            secondClicked.ForeColor = Color.Black
            firstClicked = Nothing
            secondClicked = Nothing
            Exit Sub
        ElseIf firstClicked.Text = "Dairy" And secondClicked.Text = "Milk" Then
            firstClicked.ForeColor = Color.Black
            secondClicked.ForeColor = Color.Black
            firstClicked = Nothing
            secondClicked = Nothing
            Exit Sub
        ElseIf firstClicked.Text = "Bread" And secondClicked.Text = "Grain" Then
            firstClicked.ForeColor = Color.Black
            secondClicked.ForeColor = Color.Black
            firstClicked = Nothing
            secondClicked = Nothing
            Exit Sub
        ElseIf firstClicked.Text = "Grain" And secondClicked.Text = "Bread" Then
            firstClicked.ForeColor = Color.Black
            secondClicked.ForeColor = Color.Black
            firstClicked = Nothing
            secondClicked = Nothing
            Exit Sub
        ElseIf firstClicked.Text = "Yogurt" And secondClicked.Text = "Dairy" Then
            firstClicked.ForeColor = Color.Black
            secondClicked.ForeColor = Color.Black
            firstClicked = Nothing
            secondClicked = Nothing
            Exit Sub
        ElseIf firstClicked.Text = "Dairy" And secondClicked.Text = "Yogurt" Then
            firstClicked.ForeColor = Color.Black
            secondClicked.ForeColor = Color.Black
            firstClicked = Nothing
            secondClicked = Nothing
            Exit Sub
        ElseIf firstClicked.Text = "Cookie" And secondClicked.Text = "Fats" Then
            firstClicked.ForeColor = Color.Black
            secondClicked.ForeColor = Color.Black
            firstClicked = Nothing
            secondClicked = Nothing
            Exit Sub
        ElseIf firstClicked.Text = "Fats" And secondClicked.Text = "Cookie" Then
            firstClicked.ForeColor = Color.Black
            secondClicked.ForeColor = Color.Black
            firstClicked = Nothing
            secondClicked = Nothing
            Exit Sub
        ElseIf firstClicked.Text = "Carrot" And secondClicked.Text = "Vegetable" Then
            firstClicked.ForeColor = Color.Black
            secondClicked.ForeColor = Color.Black
            firstClicked = Nothing
            secondClicked = Nothing
            Exit Sub
        ElseIf firstClicked.Text = "Vegetable" And secondClicked.Text = "Carrot" Then
            firstClicked.ForeColor = Color.Black
            secondClicked.ForeColor = Color.Black
            firstClicked = Nothing
            secondClicked = Nothing
            Exit Sub
        Else
            Timer1.Start() 'this method ONLY executes if the pair was incorrect

        End If
    End Sub
End Class
