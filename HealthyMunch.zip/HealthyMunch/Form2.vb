﻿Public Class Form2
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles lblStartInfo.Click

    End Sub

    Private Sub lblGrains_Click(sender As Object, e As EventArgs) Handles lblGrains.Click

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub
End Class