﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.lblAddInfo = New System.Windows.Forms.Label()
        Me.lblStartInfo = New System.Windows.Forms.Label()
        Me.lblGrains = New System.Windows.Forms.Label()
        Me.lblVeggies = New System.Windows.Forms.Label()
        Me.lblFruits = New System.Windows.Forms.Label()
        Me.lblDairy = New System.Windows.Forms.Label()
        Me.lblMeats = New System.Windows.Forms.Label()
        Me.lblFats = New System.Windows.Forms.Label()
        Me.lblPoints = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblAddInfo
        '
        Me.lblAddInfo.AutoSize = True
        Me.lblAddInfo.Font = New System.Drawing.Font("Comic Sans MS", 32.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddInfo.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblAddInfo.Location = New System.Drawing.Point(228, 9)
        Me.lblAddInfo.Name = "lblAddInfo"
        Me.lblAddInfo.Size = New System.Drawing.Size(499, 60)
        Me.lblAddInfo.TabIndex = 0
        Me.lblAddInfo.Text = "Additional Information"
        '
        'lblStartInfo
        '
        Me.lblStartInfo.AutoSize = True
        Me.lblStartInfo.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStartInfo.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblStartInfo.Location = New System.Drawing.Point(1, 82)
        Me.lblStartInfo.Name = "lblStartInfo"
        Me.lblStartInfo.Size = New System.Drawing.Size(343, 60)
        Me.lblStartInfo.TabIndex = 1
        Me.lblStartInfo.Text = resources.GetString("lblStartInfo.Text")
        '
        'lblGrains
        '
        Me.lblGrains.AutoSize = True
        Me.lblGrains.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGrains.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblGrains.Location = New System.Drawing.Point(1, 162)
        Me.lblGrains.Name = "lblGrains"
        Me.lblGrains.Size = New System.Drawing.Size(293, 30)
        Me.lblGrains.TabIndex = 2
        Me.lblGrains.Text = "Grains: These foods provide carbohydrates (sugars), " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "which are an important sour" &
    "ce of energy."
        '
        'lblVeggies
        '
        Me.lblVeggies.AutoSize = True
        Me.lblVeggies.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVeggies.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblVeggies.Location = New System.Drawing.Point(1, 216)
        Me.lblVeggies.Name = "lblVeggies"
        Me.lblVeggies.Size = New System.Drawing.Size(325, 30)
        Me.lblVeggies.TabIndex = 3
        Me.lblVeggies.Text = "Vegetables: These foods give us vitamins and minerals that" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " our bodies cannot pr" &
    "oduce on their own."
        '
        'lblFruits
        '
        Me.lblFruits.AutoSize = True
        Me.lblFruits.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFruits.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblFruits.Location = New System.Drawing.Point(1, 278)
        Me.lblFruits.Name = "lblFruits"
        Me.lblFruits.Size = New System.Drawing.Size(306, 30)
        Me.lblFruits.TabIndex = 4
        Me.lblFruits.Text = "Fruits: Somewhat combined with the veggie group," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " these foods give us natural su" &
    "gars, fiber, and vitamins. "
        '
        'lblDairy
        '
        Me.lblDairy.AutoSize = True
        Me.lblDairy.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDairy.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblDairy.Location = New System.Drawing.Point(1, 343)
        Me.lblDairy.Name = "lblDairy"
        Me.lblDairy.Size = New System.Drawing.Size(352, 30)
        Me.lblDairy.TabIndex = 5
        Me.lblDairy.Text = "Milk/Dairy: Dairy gives our body it’s calcium, protein, and" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " Vitamins A and D. W" &
    "hich helps our bodies grow big and strong."
        '
        'lblMeats
        '
        Me.lblMeats.AutoSize = True
        Me.lblMeats.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMeats.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblMeats.Location = New System.Drawing.Point(1, 407)
        Me.lblMeats.Name = "lblMeats"
        Me.lblMeats.Size = New System.Drawing.Size(318, 45)
        Me.lblMeats.TabIndex = 6
        Me.lblMeats.Text = "Meat and Beans/Nuts: Meat and beans/nuts gives the" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " body protein, complex carbs," &
    " iron, zinc, and Vitamin B12," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " which help build and protect our muscles."
        '
        'lblFats
        '
        Me.lblFats.AutoSize = True
        Me.lblFats.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFats.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblFats.Location = New System.Drawing.Point(1, 470)
        Me.lblFats.Name = "lblFats"
        Me.lblFats.Size = New System.Drawing.Size(399, 45)
        Me.lblFats.TabIndex = 7
        Me.lblFats.Text = resources.GetString("lblFats.Text")
        '
        'lblPoints
        '
        Me.lblPoints.AutoSize = True
        Me.lblPoints.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPoints.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblPoints.Location = New System.Drawing.Point(784, 470)
        Me.lblPoints.Name = "lblPoints"
        Me.lblPoints.Size = New System.Drawing.Size(229, 45)
        Me.lblPoints.TabIndex = 8
        Me.lblPoints.Text = "The different serving sizes of each food" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " groups will represent the points that " &
    "can" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " be earned when obtained in the game."
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(442, 163)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 31)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "="
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(442, 216)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 31)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "="
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(442, 279)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 31)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "="
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(442, 343)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 31)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "="
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(445, 407)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(29, 31)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "="
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(445, 470)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(29, 31)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "="
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1086, 541)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblPoints)
        Me.Controls.Add(Me.lblFats)
        Me.Controls.Add(Me.lblMeats)
        Me.Controls.Add(Me.lblDairy)
        Me.Controls.Add(Me.lblFruits)
        Me.Controls.Add(Me.lblVeggies)
        Me.Controls.Add(Me.lblGrains)
        Me.Controls.Add(Me.lblStartInfo)
        Me.Controls.Add(Me.lblAddInfo)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblAddInfo As Label
    Friend WithEvents lblStartInfo As Label
    Friend WithEvents lblGrains As Label
    Friend WithEvents lblVeggies As Label
    Friend WithEvents lblFruits As Label
    Friend WithEvents lblDairy As Label
    Friend WithEvents lblMeats As Label
    Friend WithEvents lblFats As Label
    Friend WithEvents lblPoints As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
End Class
