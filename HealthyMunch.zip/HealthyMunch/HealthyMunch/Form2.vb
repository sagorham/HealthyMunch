﻿Public Class Form2
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles lblStartInfo.Click

    End Sub

    Private Sub lblGrains_Click(sender As Object, e As EventArgs) Handles lblGrains.Click

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblFatPoints.Click

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

    End Sub

    Private Sub Label2_Click_1(sender As Object, e As EventArgs) Handles lblDairyPoints.Click

    End Sub
End Class