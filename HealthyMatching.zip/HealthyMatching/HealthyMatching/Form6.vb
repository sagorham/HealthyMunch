﻿Public Class Form6
    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn1.Click
        Form7.Show()
        Me.Hide()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        'Timer tick event ONLY runs if the pair of labels selcted are incorrect
        'This event stops resets the color of the two labels selcted and sets their value to Nothing
        Timer1.Stop() 'Stop timer from running to allow for future resets

        firstClicked.ForeColor = firstClicked.BackColor 'makes labels invisible
        secondClicked.ForeColor = secondClicked.BackColor

        firstClicked = Nothing 'sets label values to nothing
        secondClicked = Nothing
    End Sub
End Class