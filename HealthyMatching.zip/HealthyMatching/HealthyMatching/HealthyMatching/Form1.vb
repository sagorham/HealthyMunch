﻿Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub lblInstructions_Click(sender As Object, e As EventArgs) Handles lblInstructions.Click

    End Sub


    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        MessageBox.Show("Your username is " + inputtext.Text)
        Form2.Show()
        Me.Hide()
    End Sub
    Private Sub button2_Click(sender As Object, e As EventArgs) Handles button2.Click
        inputtext.Clear()
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub
End Class
