﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblControls = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.inputtext = New System.Windows.Forms.TextBox()
        Me.button2 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnStart = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold)
        Me.lblInstructions.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblInstructions.Location = New System.Drawing.Point(3, 145)
        Me.lblInstructions.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(1068, 208)
        Me.lblInstructions.TabIndex = 2
        Me.lblInstructions.Text = resources.GetString("lblInstructions.Text")
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Comic Sans MS", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Label2.Location = New System.Drawing.Point(454, 26)
        Me.Label2.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(561, 100)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Healthy Match"
        '
        'lblControls
        '
        Me.lblControls.AutoSize = True
        Me.lblControls.ForeColor = System.Drawing.Color.Teal
        Me.lblControls.Location = New System.Drawing.Point(14, 430)
        Me.lblControls.Name = "lblControls"
        Me.lblControls.Size = New System.Drawing.Size(253, 20)
        Me.lblControls.TabIndex = 7
        Me.lblControls.Text = "Controls: Click as Fast as You Can"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.Teal
        Me.Label3.Location = New System.Drawing.Point(413, 285)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 20)
        Me.Label3.TabIndex = 8
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(14, 484)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(161, 20)
        Me.label1.TabIndex = 14
        Me.label1.Text = "Enter your username:"
        '
        'inputtext
        '
        Me.inputtext.Location = New System.Drawing.Point(183, 484)
        Me.inputtext.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.inputtext.Name = "inputtext"
        Me.inputtext.Size = New System.Drawing.Size(178, 26)
        Me.inputtext.TabIndex = 15
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(248, 519)
        Me.button2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(133, 58)
        Me.button2.TabIndex = 16
        Me.button2.Text = "clear"
        Me.button2.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(1004, 145)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(665, 648)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 18
        Me.PictureBox1.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 20.0!, System.Drawing.FontStyle.Bold)
        Me.Label4.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Label4.Location = New System.Drawing.Point(1004, 145)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(277, 45)
        Me.Label4.TabIndex = 25
        Me.Label4.Text = "Food Pyramid!"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'btnStart
        '
        Me.btnStart.ForeColor = System.Drawing.Color.CadetBlue
        Me.btnStart.Location = New System.Drawing.Point(49, 519)
        Me.btnStart.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(151, 58)
        Me.btnStart.TabIndex = 13
        Me.btnStart.Text = "Start"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1694, 1038)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.inputtext)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblControls)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblInstructions)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblInstructions As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblControls As Label
    Friend WithEvents Label3 As Label
    Private WithEvents label1 As Label
    Private WithEvents inputtext As TextBox
    Private WithEvents button2 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents btnStart As Button
End Class
