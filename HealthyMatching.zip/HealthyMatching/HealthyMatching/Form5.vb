﻿Public Class Form5
    Public click1 As Label = Nothing
    Public click2 As Label = Nothing
    Public random As New Random
    Public food =
      New List(Of String) From {"Apple", "Fruit", "Broccoli", "Vegetable", "Chicken", "Meat", "Milk", "Dairy",
                                "Bread", "Grain", "Yogurt", "Dairy", "Cookie", "Fats", "Carrot", "Vegetable"}
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form6.Show()
        Me.Hide()
    End Sub

    Private Sub PopulateFood()
        'Method used to assign the list of strings to squares
        For Each label In TableLayoutPanel1.Controls ' All 16 labels l  isted on TableLayoutPanel1
            Dim foodLabel = TryCast(label, Label) 'Assigns 1 of the 16 labels to the variable iconLabel
            If foodLabel IsNot Nothing Then 'if foodLabel has a label assigned execute following code
                Dim randomNumber = random.Next(food.Count) 'assigns a random number from the 16 list of strings
                foodLabel.Text = food(randomNumber) 'whichever number is chosen, the text of the string will be the Label text
                foodLabel.ForeColor = foodLabel.BackColor 'sets the label to be green (invisible)
                food.RemoveAt(randomNumber) 'removes the string from the list of strings so there are no duplicates
            End If
        Next

    End Sub

    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PopulateFood()


    End Sub

    Private Sub label_Click(sender As Object, e As EventArgs) Handles Label9.Click, Label8.Click, Label7.Click, Label6.Click, Label5.Click, Label4.Click, Label3.Click, Label2.Click, Label16.Click, Label15.Click, Label14.Click, Label13.Click, Label12.Click, Label11.Click, Label10.Click, Label1.Click
        'Event runs when a label is clicked
        If Timer1.Enabled Then
            Exit Sub
        End If

        Dim selectedLabel = TryCast(sender, Label) 'assigns the selected label to variable

        If selectedLabel IsNot Nothing Then 'checks whether the clicked label has already been chosen
            If selectedLabel.ForeColor = Color.Black Then
                Exit Sub
            End If

            If click1 Is Nothing Then 'checks if click1 has a value stored
                click1 = selectedLabel 'stores label into click1
                click1.ForeColor = Color.Black 'makes label visible
                Exit Sub
            End If

            'ONLY executes if the click1 does have a label assigned
            click2 = selectedLabel 'stores the label that was selected secong into click2
            selectedLabel.ForeColor = Color.Black 'makes label visible

            MethodWin()
            CheckPair()
        End If


    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        'Timer tick event ONLY runs if the pair of labels selcted are incorrect
        'This event stops resets the color of the two labels selcted and sets their value to Nothing
        Timer1.Stop() 'Stop timer from running to allow for future resets

        click1.ForeColor = click1.BackColor 'makes labels invisible
        click2.ForeColor = click2.BackColor

        click1 = Nothing 'sets label values to nothing
        click2 = Nothing
    End Sub
    Private Sub MethodWin()
        'Event runs to see if the all of the labels are visible, meaning they have been matched correctly

        For Each label In TableLayoutPanel1.Controls
            'Loop checks every label and tests the visibility of each label
            'If the forcolor of the label is the same as the backcolor 
            'then the label is invisible meaning the the player did not finish matching all pairs
            Dim foodLabel = TryCast(label, Label)
            If foodLabel IsNot Nothing AndAlso
               foodLabel.ForeColor = foodLabel.BackColor Then
                Exit Sub
            End If
        Next


        MessageBox.Show("You matched all the icons!", "Congratulations")
        Close()

    End Sub
    Private Sub CheckPair()
        'Method called to check if a pair is correct 
        'There are 16 if statements because there are 8 pairs, but the pairs can be selected two ways
        'Ex: firstlabel = apple and secondlabel = fruit OR firstlabel = Fruit and secondlabel = apple
        If click1.Text = "Apple" And click2.Text = "Fruit" Then 'if this statement is true
            click1.ForeColor = Color.Black 'sets both labels to be visible
            click2.ForeColor = Color.Black
            click1 = Nothing 'resets the value of both labels
            click2 = Nothing
            Exit Sub ' falls out of loop

        ElseIf click1.Text = "Fruit" And click2.Text = "Apple" Then
            click1.ForeColor = Color.Black
            click2.ForeColor = Color.Black
            click1 = Nothing
            click2 = Nothing
            Exit Sub
        ElseIf click1.Text = "Broccoli" And click2.Text = "Vegetable" Then
            click1.ForeColor = Color.Black
            click2.ForeColor = Color.Black
            click1 = Nothing
            click2 = Nothing
            Exit Sub
        ElseIf click1.Text = "Vegetable" And click2.Text = "Brocolli" Then
            click1.ForeColor = Color.Black
            click2.ForeColor = Color.Black
            click1 = Nothing
            click2 = Nothing
            Exit Sub
        ElseIf click1.Text = "Chicken" And click2.Text = "Meat" Then
            click1.ForeColor = Color.Black
            click2.ForeColor = Color.Black
            click1 = Nothing
            click2 = Nothing
            Exit Sub
        ElseIf click1.Text = "Meat" And click2.Text = "Chicken" Then
            click1.ForeColor = Color.Black
            click2.ForeColor = Color.Black
            click1 = Nothing
            click2 = Nothing
            Exit Sub
        ElseIf click1.Text = "Milk" And click2.Text = "Dairy" Then
            click1.ForeColor = Color.Black
            click2.ForeColor = Color.Black
            click1 = Nothing
            click2 = Nothing
            Exit Sub
        ElseIf click1.Text = "Dairy" And click2.Text = "Milk" Then
            click1.ForeColor = Color.Black
            click2.ForeColor = Color.Black
            click1 = Nothing
            click2 = Nothing
            Exit Sub
        ElseIf click1.Text = "Bread" And click2.Text = "Grain" Then
            click1.ForeColor = Color.Black
            click2.ForeColor = Color.Black
            click1 = Nothing
            click2 = Nothing
            Exit Sub
        ElseIf click1.Text = "Grain" And click2.Text = "Bread" Then
            click1.ForeColor = Color.Black
            click2.ForeColor = Color.Black
            click1 = Nothing
            click2 = Nothing
            Exit Sub
        ElseIf click1.Text = "Yogurt" And click2.Text = "Dairy" Then
            click1.ForeColor = Color.Black
            click2.ForeColor = Color.Black
            click1 = Nothing
            click2 = Nothing
            Exit Sub
        ElseIf click1.Text = "Dairy" And click2.Text = "Yogurt" Then
            click1.ForeColor = Color.Black
            click2.ForeColor = Color.Black
            click1 = Nothing
            click2 = Nothing
            Exit Sub
        ElseIf click1.Text = "Cookie" And click2.Text = "Fats" Then
            click1.ForeColor = Color.Black
            click2.ForeColor = Color.Black
            click1 = Nothing
            click2 = Nothing
            Exit Sub
        ElseIf click1.Text = "Fats" And click2.Text = "Cookie" Then
            click1.ForeColor = Color.Black
            click2.ForeColor = Color.Black
            click1 = Nothing
            click2 = Nothing
            Exit Sub
        ElseIf click1.Text = "Carrot" And click2.Text = "Vegetable" Then
            click1.ForeColor = Color.Black
            click2.ForeColor = Color.Black
            click1 = Nothing
            click2 = Nothing
            Exit Sub
        ElseIf click1.Text = "Vegetable" And click2.Text = "Carrot" Then
            click1.ForeColor = Color.Black
            click2.ForeColor = Color.Black
            click1 = Nothing
            click2 = Nothing
            Exit Sub
        Else
            Timer1.Start() 'this method ONLY executes if the pair was incorrect

        End If
    End Sub
End Class