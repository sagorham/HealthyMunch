﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_SnakeGame
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Frm_SnakeGame))
    Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
    Me.But_NewGame = New System.Windows.Forms.ToolStripButton()
    Me.Txt_Score = New System.Windows.Forms.ToolStripTextBox()
    Me.But_Pause = New System.Windows.Forms.ToolStripButton()
    Me.But_Demo = New System.Windows.Forms.ToolStripButton()
    Me.ToolStrip1.SuspendLayout()
    Me.SuspendLayout()
    '
    'ToolStrip1
    '
    Me.ToolStrip1.AutoSize = False
    Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
    Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.But_NewGame, Me.Txt_Score, Me.But_Pause, Me.But_Demo})
    Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
    Me.ToolStrip1.Name = "ToolStrip1"
    Me.ToolStrip1.ShowItemToolTips = False
    Me.ToolStrip1.Size = New System.Drawing.Size(294, 25)
    Me.ToolStrip1.TabIndex = 0
    Me.ToolStrip1.Text = "ToolStrip1"
    '
    'But_NewGame
    '
    Me.But_NewGame.Image = CType(resources.GetObject("But_NewGame.Image"), System.Drawing.Image)
    Me.But_NewGame.ImageTransparentColor = System.Drawing.Color.Magenta
    Me.But_NewGame.Name = "But_NewGame"
    Me.But_NewGame.Size = New System.Drawing.Size(85, 22)
    Me.But_NewGame.Text = "New Game"
    '
    'Txt_Score
    '
    Me.Txt_Score.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
    Me.Txt_Score.BackColor = System.Drawing.Color.White
    Me.Txt_Score.Name = "Txt_Score"
    Me.Txt_Score.ReadOnly = True
    Me.Txt_Score.Size = New System.Drawing.Size(75, 25)
    Me.Txt_Score.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'But_Pause
    '
    Me.But_Pause.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
    Me.But_Pause.Image = CType(resources.GetObject("But_Pause.Image"), System.Drawing.Image)
    Me.But_Pause.ImageTransparentColor = System.Drawing.Color.Magenta
    Me.But_Pause.Name = "But_Pause"
    Me.But_Pause.Size = New System.Drawing.Size(42, 22)
    Me.But_Pause.Text = "Pause"
    Me.But_Pause.Visible = False
    '
    'But_Demo
    '
    Me.But_Demo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.But_Demo.Image = CType(resources.GetObject("But_Demo.Image"), System.Drawing.Image)
    Me.But_Demo.ImageTransparentColor = System.Drawing.Color.Magenta
    Me.But_Demo.Name = "But_Demo"
    Me.But_Demo.Size = New System.Drawing.Size(23, 22)
    Me.But_Demo.Text = "ToolStripButton1"
    '
    'Frm_SnakeGame
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(294, 299)
    Me.Controls.Add(Me.ToolStrip1)
    Me.DoubleBuffered = True
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
    Me.KeyPreview = True
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "Frm_SnakeGame"
    Me.ShowIcon = False
    Me.Text = "Snake Game"
    Me.ToolStrip1.ResumeLayout(False)
    Me.ToolStrip1.PerformLayout()
    Me.ResumeLayout(False)

  End Sub
  Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
  Friend WithEvents But_NewGame As System.Windows.Forms.ToolStripButton
  Friend WithEvents Txt_Score As System.Windows.Forms.ToolStripTextBox
  Friend WithEvents But_Pause As System.Windows.Forms.ToolStripButton
  Friend WithEvents But_Demo As System.Windows.Forms.ToolStripButton

End Class
