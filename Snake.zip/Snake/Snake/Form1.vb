﻿Public Class Frm_SnakeGame
  Protected Friend mGs As GamingStates = GamingStates.Player
  Private WithEvents PlayingGame As SnakeGame
  Private WithEvents PlayerGame As SnakeGame
  Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
    If PlayingGame.GameState = GameState.Playing Then
      Select Case e.KeyCode
        Case Keys.Up : PlayingGame.Move(MoveDirections.North)
        Case Keys.Right : PlayingGame.Move(MoveDirections.East)
        Case Keys.Down : PlayingGame.Move(MoveDirections.South)
        Case Keys.Left : PlayingGame.Move(MoveDirections.West)
      End Select
    End If
  End Sub
  Public Sub HandleGameUpdate()
    Me.Txt_Score.Text = PlayingGame.Points
    Me.Invalidate()
  End Sub
  Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint
    If PlayingGame IsNot Nothing Then PlayingGame.Draw(e.Graphics)
  End Sub
  Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs)
    If PlayingGame.GameState = GameState.Playing Then PlayingGame.Move()
  End Sub
  Public Sub HandleGameOver()
    Me.But_NewGame.Enabled = True
    Me.But_Pause.Visible = False
  End Sub
  Private Sub NewGameButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles But_NewGame.Click
    Txt_Score.Text = 0
    But_NewGame.Enabled = False
    But_Pause.Visible = True
    PlayerGame = New SnakeGame
    AddHandler PlayerGame.GameOver, AddressOf HandleGameOver
    AddHandler PlayerGame.Updated, AddressOf HandleGameUpdate
    PlayingGame = PlayerGame
  End Sub
  Private Sub But_Pause_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles But_Pause.Click
    PlayingGame = PlayerGame
    If PlayerGame.GameState = GameState.Paused Then
      PlayingGame = PlayerGame
      PlayingGame.Pause()
    Else
      PlayingGame.Pause()

    End If
  End Sub
  Dim demoGame As SnakeGame
  Dim demo As DemoPlayer
  Private Sub But_Demo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles But_Demo.Click
    If PlayingGame IsNot Nothing Then PlayingGame.Pause()
    demoGame = New SnakeGame
    AddHandler demoGame.Updated, AddressOf Me.HandleGameUpdate
    mGs = GamingStates.Demo
    PlayingGame = demoGame
    demo = New DemoPlayer(PlayingGame)

  End Sub


End Class