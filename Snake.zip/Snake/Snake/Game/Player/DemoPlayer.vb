﻿Public Class DemoPlayer
  Protected Friend mGame As SnakeGame
  Protected Friend mRnd As New Random
  Protected Friend mDemoPlay As New System.Windows.Forms.Timer With {.Interval = 500, .Enabled = True}
  Public Sub New(ByRef g As SnakeGame)
    mGame = g
    AddHandler mDemoPlay.Tick, AddressOf TheDemoPlayer
    AddHandler mGame.GameOver, AddressOf GameOver
  End Sub
  Public Sub GameOver()
    mGame = New SnakeGame
  End Sub
  Private Sub TheDemoPlayer(ByVal sender As System.Object, ByVal e As System.EventArgs)
    Dim n = mRnd.NextDouble
    Select Case mGame.mSnake.Heading
      Case MoveDirections.North
        Select Case n
          Case n <= 0.3 : mGame.Move(MoveDirections.North)
          Case (n > 0.3) AndAlso (n <= 0.6) : mGame.Move(MoveDirections.East)
          Case (n > 0.6) AndAlso (n <= 0.9) : mGame.Move(MoveDirections.West)
          Case n > 0.9 : mGame.Move(MoveDirections.South)
        End Select
      Case MoveDirections.East
        Select Case True
          Case n <= 0.3 : mGame.Move(MoveDirections.East)
          Case (n > 0.3) AndAlso (n <= 0.6) : mGame.Move(MoveDirections.North)
          Case (n > 0.6) AndAlso (n <= 0.9) : mGame.Move(MoveDirections.South)
          Case n > 0.9 : mGame.Move(MoveDirections.West)
        End Select
      Case MoveDirections.South
        Select Case n
          Case n <= 0.3 : mGame.Move(MoveDirections.South)
          Case (n > 0.3) AndAlso (n <= 0.6) : mGame.Move(MoveDirections.East)
          Case (n > 0.6) AndAlso (n <= 0.9) : mGame.Move(MoveDirections.West)
          Case n > 0.9 : mGame.Move(MoveDirections.North)
        End Select
      Case MoveDirections.West
        Select Case n
          Case n <= 0.3 : mGame.Move(MoveDirections.West)
          Case (n > 0.3) AndAlso (n <= 0.6) : mGame.Move(MoveDirections.South)
          Case (n > 0.6) AndAlso (n <= 0.9) : mGame.Move(MoveDirections.North)
          Case n > 0.9 : mGame.Move(MoveDirections.East)
        End Select
    End Select
    My.Application.DoEvents()
  End Sub
End Class
