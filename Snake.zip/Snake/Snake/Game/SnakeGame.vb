﻿Public Class SnakeGame
  Protected Friend mBounds As New Rectangle(0, 25, 300, 300)
  Protected Friend mSize As Integer = 10
  Protected Friend mRnd As New Random
  Protected Friend WithEvents mSnake As Snake
  Protected Friend mFood As New List(Of Food)
  Protected Friend mGameState As GameState
  Protected Friend mInitialFood As Integer = 4
  Protected Friend mPoints As Integer = 0
  Protected Friend mTick As New System.Windows.Forms.Timer With {.Interval = 500, .Enabled = True}
#Region "Events"
  Public Event GameOver()
  Public Event Updated()
#End Region
#Region "ReadOnly Properties"
  Public ReadOnly Property Points As Integer
    Get
      Return mPoints
    End Get
  End Property
  Public ReadOnly Property GameState
    Get
      Return mGameState
    End Get
  End Property
#End Region
  Private Sub Tick(ByVal sender As System.Object, ByVal e As System.EventArgs)
    If GameState = GameState.Playing Then Move()
  End Sub
  Public Sub New()
    ' Initialise a new Snake
    mSnake = New Snake(Me)
    ' Populate the world with some food.
    For i = 1 To mInitialFood
      AddNewPieceOfFood()
    Next
    AddHandler mSnake.IsDead, AddressOf HandleDeadSnake
    AddHandler mSnake.EatenFood, AddressOf HasEatenFood
    mGameState = GameState.Playing
    AddHandler mTick.Tick, AddressOf Tick
  End Sub
  Public Sub Pause()
    If mGameState = GameState.Playing Then
      mGameState = GameState.Paused
    ElseIf mGameState = GameState.Paused Then
      mGameState = GameState.Playing
    End If
  End Sub
  Private Sub HasEatenFood(ByRef f As Food)
    mFood.Remove(f)
    mPoints += 1
    If mFood.Any = False Then AddNewPieceOfFood()
  End Sub
  Private Sub HandleDeadSnake() Handles mSnake.IsDead
    mGameState = GameState.GameOver
    RaiseEvent GameOver()
  End Sub
  Public Sub Move()
    Move(mSnake.Heading)
  End Sub
  Public Sub Move(ByVal md As MoveDirections)
    mSnake.Move(md)
    If mRnd.NextDouble <= 0.1 Then AddNewPieceOfFood()
    RaiseEvent Updated()
  End Sub
  Private Sub AddNewPieceOfFood()
    Dim x As Integer = 0
    Dim y As Integer = 0
     Dim fr As Food = Nothing
    Dim OverFood As Boolean = True
    Dim OverSnake As Boolean = True
    Do
      x = mRnd.Next(0, 20)
      y = mRnd.Next(0, 20)
      fr = New Food(Me, Color.Purple, x * mSize, y * mSize)
      OverFood = mFood.Any(Function(f As Food) f.Rect.IntersectsWith(fr.Rect))
      OverSnake = mSnake.mParts.Any(Function(s As SnakePart) s.mRect.IntersectsWith(fr.Rect))
    Loop Until Not (OverFood OrElse OverSnake)
    mFood.Add(New Food(Me, fr.Color, fr.Rect.X, fr.Rect.Y))
  End Sub
  Public Sub Draw(ByRef g As Graphics)
    For Each fp As Food In mFood
      fp.Draw(g)
    Next
    mSnake.DrawSnake(g)
  End Sub
End Class