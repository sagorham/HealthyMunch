﻿Public Enum GamingStates As Integer
  Demo = 0
  Player = 1
End Enum
