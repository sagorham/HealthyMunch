﻿Public Class Snake
  Public Event IsDead()
  Protected Friend mLand As SnakeGame
  Protected Friend mHead As Color = Color.Yellow
  Protected Friend mBody As Color = Color.Green
  Protected Friend mParts As New Queue(Of SnakePart)
  Protected Friend mHeading As MoveDirections = MoveDirections.East

  Public Event EatenFood(ByRef f As Food)
  
  Public Sub New(ByRef onLand As SnakeGame)
    mLand = onLand
    For i = 0 To 30 Step 10
      mParts.Enqueue(New SnakePart(Color.Green, i, 50))
    Next
    mParts.Last.Color = Color.Yellow
  End Sub
  Public Property Heading() As MoveDirections
    Get
      Return mHeading
    End Get
    Set(ByVal value As MoveDirections)
      If [Enum].IsDefined(GetType(MoveDirections), value) Then mHeading = value
    End Set
  End Property
  Public Sub Move(ByVal md As MoveDirections, Optional ByVal Lengthen As Boolean = False)
    If [Enum].IsDefined(GetType(MoveDirections), md) = False Then Throw New ArgumentException(String.Format("{0} is not a valid value.", md))
    mHeading = md
    If mParts.Count > 0 Then
      mParts.Last.Color = mBody
      Dim sp As SnakePart = Nothing
      Select Case md
        Case MoveDirections.North : sp = New SnakePart(Color.Yellow, mParts.Last.mRect.X, mParts.Last.mRect.Y - mLand.mSize)
        Case MoveDirections.East : sp = New SnakePart(Color.Yellow, mParts.Last.mRect.X + mLand.mSize, mParts.Last.mRect.Y)
        Case MoveDirections.South : sp = New SnakePart(Color.Yellow, mParts.Last.mRect.X, mParts.Last.mRect.Y + mLand.mSize)
        Case MoveDirections.West : sp = New SnakePart(Color.Yellow, mParts.Last.mRect.X - mLand.mSize, mParts.Last.mRect.Y)
      End Select
      Dim ft As IEnumerable(Of Food) = mLand.mFood.Where(Function(fp As Food) fp.Rect.IntersectsWith(sp.mRect))
      If ft.Any Then
        Lengthen = True
        RaiseEvent EatenFood(ft(0))
       End If
      If Not Lengthen Then mParts.Dequeue()
      Dim MoveIntoSelf = mParts.Any(Function(dd As SnakePart) dd.mRect.IntersectsWith(sp.mRect))
      ' Check to see if snake is dead
      If MoveIntoSelf Then RaiseEvent IsDead()
      If sp.mRect.X < mLand.mBounds.Left Then RaiseEvent IsDead()
      If sp.mRect.X > mLand.mBounds.Right Then RaiseEvent IsDead()
      If sp.mRect.Y < mLand.mBounds.Top Then RaiseEvent IsDead()
      If sp.mRect.Y > mLand.mBounds.Bottom Then RaiseEvent IsDead()
      mParts.Enqueue(sp)
    End If
  End Sub
  Public Sub DrawSnake(ByRef g As Graphics)
    For Each sp As SnakePart In mParts
      Using b As New Pen(sp.Color)
        g.FillRectangle(b.Brush, sp.mRect)
        g.DrawRectangle(Pens.Black, sp.mRect)
      End Using
    Next
  End Sub
End Class