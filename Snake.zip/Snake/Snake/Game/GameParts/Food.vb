﻿Public Class Food
  Protected Friend mColor As Color
  Protected Friend mRect As Rectangle
  Public ReadOnly Property Color() As Color
    Get
      Return mColor
    End Get
  End Property
  Public ReadOnly Property Rect As Rectangle
    Get
      Return mRect
    End Get
  End Property

  Public Sub New(ByRef land As SnakeGame, ByVal c As Color, ByVal x As Integer, ByVal y As Integer)
    mColor = c
    mRect = New Rectangle(x + land.mBounds.Left, y + land.mBounds.Top, land.mSize, land.mSize)
  End Sub
  Public Sub Draw(ByRef g As Graphics)
    Using b As New Pen(mColor)
      g.FillEllipse(b.Brush, mRect)
      g.DrawEllipse(Pens.Black, mRect)
    End Using
  End Sub
End Class
