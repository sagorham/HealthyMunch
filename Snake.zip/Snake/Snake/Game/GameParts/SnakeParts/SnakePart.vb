﻿Public Class SnakePart
  Protected Friend mColor As Color
  Protected Friend mRect As Rectangle
  Public Property Color() As Color
    Get
      Return mColor
    End Get
    Set(ByVal value As Color)
      mColor = value
    End Set
  End Property
  Public Sub New()
    mColor = Drawing.Color.Yellow
    mRect = New Rectangle(0, 0, 10, 10)
  End Sub
  Public Sub New(ByVal c As Color, ByVal x As Integer, ByVal y As Integer)
    mColor = c
    mRect = New Rectangle(x, y, 10, 10)
  End Sub
End Class