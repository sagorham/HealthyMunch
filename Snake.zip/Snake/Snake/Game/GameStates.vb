﻿Public Enum GameState As Integer
  GameOver = 0
  Playing = 1
  Paused = 2
End Enum